from setuptools import setup, find_packages

with open('app/Readme.md', 'r') as f:
    long_description = f.read()
    
setup(
    name='bojan',
    version='0.0.1',
    description='A simple logging library',
    author='Daniel Grydin',
    package_dir={'': 'app'},
    packages=find_packages(where='app'),
    long_description=long_description,
    long_description_content_type='text/markdown',
    url="",
    author_email="",
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    install_requires=[],
    extras_require={
        "dev": [
            "pytest>=7.0",
            "twine>=4.0.2",
        ],
    },
    python_requires='>=3.6'
)